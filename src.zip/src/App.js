// App.js or wherever your routes are declared
import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import RoleSelect from "./RoleSelect";
import LoginSignup from "./LoginSignup";
import DashboardMentor from "./DashboardMentor";
import Layout from "./Layout";
import Home from "./Homepage";
import Dashboard from "./Dashboard";
import Profile from "./Profile";
import Chat from "./ChatUI";
import EditProfile from "./EditProfile"; // If you have a separate component


function App() {
  return (
    <Router>
      <Routes>
        {/* Public route for login/signup */}
        <Route path="/" element={<RoleSelect />} />       {/* New default */}
        <Route path="/login" element={<LoginSignup />} />
        {/* Redirect root to home */}
        <Route path="/" element={<Navigate to="/home" replace />} />

        {/* Protected routes inside the Layout */}
        <Route element={<Layout />}>
          <Route path="/home" element={<Home />} />
          <Route path="/mentor-dashboard" element={<DashboardMentor />} />
          <Route path="/dashboard-overview" element={<Dashboard />} /> {/* Add this */}
          <Route path="/profile" element={<Profile />} />
          <Route path="/edit-profile" element={<EditProfile />} /> {/* Or EditProfile if you have it */}
          <Route path="/chat" element={<Chat />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;









