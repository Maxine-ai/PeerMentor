// src/App.js
import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./Layout"; // the sidebar wrapper
//import Home from "./Home";
import Homepage from "./Homepage";
import Dashboard from "./Dashboard";
import Profile from "./Profile";
import ChatUI from "./ChatUI";
import EditProfile from "./EditProfile"; // at the top
//import Settings from "./Settings";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Routes wrapped with persistent sidebar */}
          
          <Route element={<Layout />}>
          <Route path="/home" element={<Homepage />} />
          <Route path="/dashboard-overview" element={<Dashboard />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/chat" element={<ChatUI />} />
          <Route path="/edit-profile" element={<EditProfile />} />

        </Route>
        {/* Optional public route for login or landing page */}
        {/* <Route path="/" element={<Login />} /> */}
      </Routes>
    </BrowserRouter>
  );
}

export default App;








