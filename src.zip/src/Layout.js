// src/Layout.js
import React from "react";
import { useNavigate, Outlet } from "react-router-dom";
import "./Layout.css";

const Layout = () => {
  const navigate = useNavigate();

  return (
    <div className="layout">
      <aside className="sidebar">
        <div className="logo">MAKE</div>
        <ul className="nav-icons">
          <li onClick={() => navigate("/home")} title="Home">🏠</li>
          <li onClick={() => navigate("/dashboard-overview")} title="Dashboard">📋</li>
          <li onClick={() => navigate("/profile")} title="Profile">👤</li>
          <li onClick={() => navigate("/chat")} title="Messages">💬</li>
          <li onClick={() => navigate("/settings")} title="Settings">⚙️</li>
        </ul>
      </aside>

      <main className="page-content">
        <Outlet />
      </main>
    </div>
  );
};

export default Layout;
